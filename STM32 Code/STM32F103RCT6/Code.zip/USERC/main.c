#include "stm32f10x.h"
#include "SysTick.h"
#include "UART.h"
#include "ADC.h"

int main(void)
{
    uint16_t ADC_Result;
    
    SysTick_Init();//滴答定时器初始化
    UART1_Init();//UART1初始化
    ADC1_Init();//ADC1初始化
    
    printf("Light sensitive module sampling value!\n");//打印光敏模块采样值！
    
    while(1)
    {
        ADC_Result = ADC1_Result();//获取ADC转换数据
        printf("ADC_Result = %d\r\n",ADC_Result);//打印ADC转换数据
				Delay_us(100000);
    }
}
